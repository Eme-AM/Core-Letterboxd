package com.example.CoreBack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
